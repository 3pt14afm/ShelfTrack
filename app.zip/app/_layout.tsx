// app/_layout.tsx
import "../global.css";
import { useEffect } from "react";
import { Stack, useRouter, useSegments } from "expo-router";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { View, ActivityIndicator } from "react-native";
import { useAuthListener } from "@/hooks/useAuth";
import { useAuthStore } from "@/store/authStore";

export default function RootLayout() {
  useAuthListener();
  const session = useAuthStore((s) => s.session);
  const profile = useAuthStore((s) => s.profile);
  const isLoading = useAuthStore((s) => s.isLoading);
  const segments = useSegments();
  const router = useRouter();

  useEffect(() => {
    if (isLoading) return; // wait until initial session check finishes

    const group = segments[0]; // "(auth)" | "(librarian)" | "(student)" | undefined
    const inLibrarianGroup = group === "(librarian)";
    const inStudentGroup = group === "(student)";

    if (!session) {
      // Logged out but sitting inside a protected group -> kick to index
      if (inLibrarianGroup || inStudentGroup) {
        router.replace("/");
      }
      return;
    }

    if (session && profile) {
      if (profile.role === "librarian" && inStudentGroup) {
        router.replace("/(librarian)");
      }
      if (profile.role === "student" && inLibrarianGroup) {
        router.replace("/(student)");
      }
    }
  }, [session, profile, isLoading, segments]);

  return (
    <SafeAreaProvider>
      <Stack
        screenOptions={{
          headerShown: false,
          contentStyle: { backgroundColor: "#ffffff" },
          animation: "none",
        }}
      />
      {isLoading && (
        <View className="absolute inset-0 items-center justify-center bg-surface z-50">
          <ActivityIndicator size="large" color="#164a2d" />
        </View>
      )}
    </SafeAreaProvider>
  );
}