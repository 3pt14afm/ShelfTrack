import { View, Text, Pressable } from "react-native";
import { logout } from "@/lib/auth-helpers";
import { useAuthStore } from "@/store/authStore";

export default function LibrarianDashboard() {
  const profile = useAuthStore((s) => s.profile);

  async function handleLogout() {
    await logout();
  }

  return (
    <View className="flex-1 items-center justify-center bg-surface px-6">
      <Text className="text-xl text-shelf-700 mb-2">Librarian Dashboard</Text>
      <Text className="text-muted mb-8">
        Logged in as {profile?.full_name ?? "Default Librarian"}
      </Text>

      <Pressable
        onPress={handleLogout}
        className="bg-shelf-600 rounded-xl px-6 py-3"
      >
        <Text className="text-white font-semibold">Logout</Text>
      </Pressable>
    </View>
  );
}