// app/(librarian)/_layout.tsx
import { Tabs, Redirect } from "expo-router";
import { View, ActivityIndicator } from "react-native";
import { useAuthStore } from "@/store/authStore";

export default function LibrarianLayout() {
  const session = useAuthStore((s) => s.session);
  const profile = useAuthStore((s) => s.profile);

  if (!session || !profile) {
    return <Redirect href="/" />;
  }

  if (profile.role !== "librarian") {
    return <Redirect href="/" />;
  }

  if (profile.must_change_password) {
    return <Redirect href="/change-password" />;
  }

  return (
    <Tabs screenOptions={{ headerShown: false }}>
      <Tabs.Screen name="index" options={{ title: "Dashboard" }} />
    </Tabs>
  );
}