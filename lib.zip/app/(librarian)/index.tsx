// app/(librarian)/index.tsx
import { useState } from "react";
import { View, Text, Pressable, ActivityIndicator } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { logout } from "@/lib/auth-helpers";
import { useAuthStore } from "@/store/authStore";

export default function LibrarianDashboard() {
  const profile = useAuthStore((s) => s.profile);
  const [loggingOut, setLoggingOut] = useState(false);

async function handleLogout() {
  if (loggingOut) return;

  setLoggingOut(true);

  try {
    await logout();
  } finally {
    setLoggingOut(false);
  }
}

  return (
    <SafeAreaView edges={["top", "bottom"]} className="flex-1 bg-surface">
      <View className="flex-1 items-center justify-center px-6">
        <Text className="text-xl text-shelf-700 mb-2">Librarian Dashboard</Text>
        <Text className="text-muted mb-8">
          Logged in as {profile?.full_name ?? "Default Librarian"}
        </Text>

        <Pressable
          onPress={handleLogout}
          disabled={loggingOut}
          className="bg-shelf-600 rounded-xl px-6 py-3 disabled:opacity-50"
        >
          {loggingOut ? (
            <ActivityIndicator color="white" />
          ) : (
            <Text className="text-white font-semibold">Logout</Text>
          )}
        </Pressable>
      </View>
    </SafeAreaView>
  );
}