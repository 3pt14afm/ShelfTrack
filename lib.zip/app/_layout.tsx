// app/_layout.tsx
import "../global.css";

import { Stack, Redirect, useSegments } from "expo-router";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { View, ActivityIndicator } from "react-native";

import { useAuthListener } from "@/hooks/useAuth";
import { useAuthStore } from "@/store/authStore";

export default function RootLayout() {
  useAuthListener();

  const session = useAuthStore((s) => s.session);
  const profile = useAuthStore((s) => s.profile);
  const isLoading = useAuthStore((s) => s.isLoading);

  const segments = useSegments();

  if (isLoading) {
    return (
      <SafeAreaProvider>
        <View className="flex-1 items-center justify-center bg-surface">
          <ActivityIndicator size="large" color="#164a2d" />
        </View>
      </SafeAreaProvider>
    );
  }

  const group = segments[0];
  const inAuth = group === "(auth)";
  const inLibrarian = group === "(librarian)";
  const inStudent = group === "(student)";

  if (!session) {
    if (inLibrarian || inStudent) {
      return <Redirect href="/" />;
    }
  } else if (profile) {
    if (profile.must_change_password) {
      return <Redirect href="/change-password" />;
    }

    if (inAuth || (!inLibrarian && !inStudent)) {
      return (
        <Redirect
          href={profile.role === "librarian" ? "/(librarian)" : "/(student)"}
        />
      );
    }

    if (profile.role === "librarian" && inStudent) {
      return <Redirect href="/(librarian)" />;
    }

    if (profile.role === "student" && inLibrarian) {
      return <Redirect href="/(student)" />;
    }
  }

  return (
    <SafeAreaProvider>
      <Stack
        screenOptions={{
          headerShown: false,
          animation: "none",
          contentStyle: {
            backgroundColor: "#ffffff",
          },
        }}
      />
    </SafeAreaProvider>
  );
}